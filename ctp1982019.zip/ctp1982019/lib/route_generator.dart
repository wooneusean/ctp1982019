import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void _showSnackBar(BuildContext context, snackBarMessages msg) {
  String message;
  switch (msg) {
    case snackBarMessages.EMPTYEMAILPASS:
      message = 'Email and password must not be empty!';
      break;
    case snackBarMessages.EMAILPASSMISMATCH:
      message = 'Wrong email and/or password!';
      break;
    case snackBarMessages.SERVERDOWN:
      message = 'Server is down!';
      break;
    case snackBarMessages.USERNOTVERIFIED:
      message = 'Your account has not yet been verified!';
      break;
    default:
      message = 'Unknown error occured!';
      break;
  }

  Scaffold.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
    ),
  );
}

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    final args = settings.arguments;

    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => LoginPage());
      case '/home':
        return MaterialPageRoute(
          builder: (_) => HomePage(
            token: args.toString(),
          ),
        );
      default:
        return MaterialPageRoute(builder: (_) => ErrorPage());
    }
  }
}

class ErrorPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SizedBox(
          child: Text('Error'),
          width: double.infinity,
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  LoginPage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _LoginPageState createState() => _LoginPageState();
}

enum snackBarMessages {
  EMPTYEMAILPASS,
  EMAILPASSMISMATCH,
  SERVERDOWN,
  USERNOTVERIFIED,
}

class _LoginPageState extends State<LoginPage> {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  var token;

  Future login(String email, String password, BuildContext context) async {
    final url = 'http://10.0.2.2/ctp1982019/login.php';
    try {
      final response = await http.post(url, body: {
        'email': email,
        'password': password
      }).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        setState(() {
          // debugPrint(response.body);
          token = jsonDecode(response.body);
          debugPrint(token['res'].toString());
          if (token.isNotEmpty) {
            if (token['res'] == '0') {
              _showSnackBar(context, snackBarMessages.EMAILPASSMISMATCH);
            } else if (token['res'] == '1') {
              _showSnackBar(context, snackBarMessages.USERNOTVERIFIED);
            } else {
              Navigator.of(context)
                  .pushReplacementNamed('/home', arguments: token['res']);
            }
          }
        });
      }
    } on TimeoutException catch (_) {
      _showSnackBar(context, snackBarMessages.SERVERDOWN);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Builder(
        builder: (context) => SafeArea(
          child: ListView(
            padding: EdgeInsets.symmetric(horizontal: 24.0),
            children: <Widget>[
              SizedBox(height: 120.0),
              TextField(
                controller: emailCtrl,
                decoration: InputDecoration(labelText: 'Email', filled: true),
              ),
              SizedBox(height: 12.0),
              TextField(
                controller: passCtrl,
                decoration:
                    InputDecoration(labelText: 'Password', filled: true),
                obscureText: true,
              ),
              ButtonBar(
                children: <Widget>[
                  RaisedButton(
                    child: Text('Login'),
                    onPressed: () {
                      setState(() {
                        if (emailCtrl.text.isEmpty || passCtrl.text.isEmpty) {
                          _showSnackBar(
                              context, snackBarMessages.EMPTYEMAILPASS);
                        } else {
                          login(emailCtrl.text, passCtrl.text, context);
                        }
                      });
                    },
                  ),
                  FlatButton(
                    child: Text('Register'),
                    onPressed: () {},
                  )
                ],
              ),
            ],
          ),
        ),
      ),

//      body: Center(
//        child: _buildUserData(context),
//      ),
    );
  }
}

class HomePage extends StatefulWidget {
  HomePage({Key key, this.token}) : super(key: key);

  final String token;

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var userData;
  Future getUserData(String token, BuildContext context) async {
    final url = 'http://10.0.2.2/ctp1982019/user.php';
    try {
      final response = await http.post(url,
          body: {'token': widget.token}).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        setState(() {
          // debugPrint(response.body);
          userData = jsonDecode(response.body);
          debugPrint(response.body);
          if (userData.isEmpty) {
            // fix this
          }
        });
      }
    } on TimeoutException catch (_) {
      _showSnackBar(context, snackBarMessages.SERVERDOWN);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: Builder(
        builder: (context) => SafeArea(
            child:ListView(children: <Widget>[
              Text(userData['email']),
              Text(userData['balance'])
            ],),

        ),
      ),
    );
  }
}
